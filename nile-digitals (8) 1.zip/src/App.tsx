import { useState, useEffect } from 'react';
import { Language } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Services from './components/Services';
import Work from './components/Work';
import Contact from './components/Contact';
import Support from './components/Support';
import Footer from './components/Footer';

export default function App() {
  const [currentLang, setCurrentLang] = useState<Language>('en');
  const [activeSection, setActiveSection] = useState<string>('home');

  // Monitor active viewing section using an IntersectionObserver
  useEffect(() => {
    const sections = ['home', 'services', 'work', 'contact'];
    const observers = sections.map((id) => {
      const element = document.getElementById(id);
      if (!element) return null;

      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setActiveSection(id);
          }
        },
        {
          rootMargin: '-30% 0px -60% 0px' // Detect viewport focus accurately
        }
      );

      observer.observe(element);
      return { observer, element };
    });

    return () => {
      observers.forEach((obs) => {
        if (obs) {
          obs.observer.unobserve(obs.element);
        }
      });
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#faf8f5] text-stone-900 selection:bg-[#c5a880]/30 selection:text-[#1c1917] antialiased">
      {/* Premium Fixed Header with active link and core switcher */}
      <Header
        currentLang={currentLang}
        setLang={setCurrentLang}
        activeSection={activeSection}
      />

      <main id="main-content">
        {/* Full-Screen Crossfaded Hero Slider */}
        <Hero currentLang={currentLang} />

        {/* Feature list highlights (Mobile, MultiLang, Speed, SEO, WhatsApp, Support) */}
        <Features currentLang={currentLang} />

        {/* 4 Cards Simple Services Block */}
        <Services currentLang={currentLang} />

        {/* Selected Portfolio Masonry showcasing live Netlify URLs */}
        <Work currentLang={currentLang} />

        {/* Inquiry Input + WhatsApp direct click option */}
        <Contact currentLang={currentLang} />
      </main>

      {/* Persistent floating help desk triggers support panel */}
      <Support currentLang={currentLang} />

      {/* Simple high-end brand footer with insta links */}
      <Footer currentLang={currentLang} />
    </div>
  );
}


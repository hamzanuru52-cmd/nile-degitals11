export type Language = 'en' | 'am' | 'om' | 'ti';

export interface TranslationSet {
  navHome: string;
  navServices: string;
  navWork: string;
  navContact: string;

  heroTitle: string;
  heroSub: string;
  heroTags: string[];
  heroTrust: string;
  btnStart: string;
  btnWork: string;

  featuresTitle: string;
  featResponsive: string;
  featMultilingual: string;
  featFastLoading: string;
  featSEO: string;
  featWhatsApp: string;
  featCustSupport: string;
  featModernUI: string;

  servicesTitle: string;
  servicesSubtitle: string;
  webDevTitle: string;
  webDevDesc: string;
  smmTitle: string;
  smmDesc: string;
  reviewsTitle: string;
  reviewsDesc: string;
  brandingTitle: string;
  brandingDesc: string;

  workTitle: string;
  workSubtitle: string;
  workAll: string;
  workHotels: string;
  workRestaurants: string;
  workHealthcare: string;
  workOther: string;
  workFeatured: string;
  btnViewProject: string;

  contactTitle: string;
  contactSubtitle: string;
  formName: string;
  formNamePl: string;
  formBusiness: string;
  formBusinessPl: string;
  formService: string;
  formServiceSelect: string;
  formDesc: string;
  formDescPl: string;
  formDetails: string;
  formDetailsPl: string;
  btnSend: string;
  btnWhatsAppForm: string;
  successMessage: string;

  supportTitle: string;
  supportSub: string;
  supportHours: string;
  btnCall: string;

  footerText: string;
  footerQuickLinks: string;
  footerSocials: string;
  footerCopyright: string;
}

export const translations: Record<Language, TranslationSet> = {
  en: {
    navHome: 'Home',
    navServices: 'Services',
    navWork: 'Our Work',
    navContact: 'Contact',

    heroTitle: 'Helping Businesses Grow Online',
    heroSub: 'Professional websites, digital marketing, branding, and business promotion designed to help your business stand out and grow.',
    heroTags: ['Website Development', 'Social Media Marketing', 'Branding', 'Business Promotion'],
    heroTrust: 'Helping hotels, restaurants, clinics, and businesses build a stronger digital presence across Ethiopia.',
    btnStart: 'Start Your Project',
    btnWork: 'View Our Work',

    featuresTitle: 'Why Partners Choose Nile Digitals',
    featResponsive: 'Mobile Responsive',
    featMultilingual: 'Multilingual Support',
    featFastLoading: 'Fast Loading',
    featSEO: 'SEO Ready',
    featWhatsApp: 'WhatsApp Integration',
    featCustSupport: 'Customer Support',
    featModernUI: 'Modern UI/UX',

    servicesTitle: 'Our Services',
    servicesSubtitle: 'Tailored solutions designed to make your business stand out and thrive in the modern market.',
    webDevTitle: 'Website Development',
    webDevDesc: 'Custom websites for hotels, restaurants, clinics, gyms, construction companies, suppliers, and businesses.',
    smmTitle: 'Social Media Marketing',
    smmDesc: 'Grow your audience and increase business visibility across major social media channels.',
    reviewsTitle: 'Business Reviews & Promotion',
    reviewsDesc: 'Help businesses gain exposure, aggregate clean positive feedback, and build real digital trust.',
    brandingTitle: 'Branding',
    brandingDesc: 'Improve business identity, define custom aesthetic palettes, and polish your online presence.',

    workTitle: 'Our Work',
    workSubtitle: 'Explore case studies of premium and tailored digital platforms engineered to perform.',
    workAll: 'All Projects',
    workHotels: 'Hotels',
    workRestaurants: 'Restaurants & Cafes',
    workHealthcare: 'Healthcare',
    workOther: 'Other Businesses',
    workFeatured: 'Featured Case Study',
    btnViewProject: 'View Project',

    contactTitle: 'Start Your Project',
    contactSubtitle: 'Let us know how we can help upgrade your digital presence. Get a response in minutes.',
    formName: 'Full Name',
    formNamePl: 'Your Name',
    formBusiness: 'Business Name',
    formBusinessPl: 'e.g. Yiganda Hotel',
    formService: 'Service Needed',
    formServiceSelect: 'Select a Service',
    formDesc: 'Business Description',
    formDescPl: 'Tell us briefly about your business...',
    formDetails: 'Additional Details',
    formDetailsPl: 'What components or screens do you require?',
    btnSend: 'Send Inquiry',
    btnWhatsAppForm: 'WhatsApp Us',
    successMessage: 'Thank you for your inquiry! We will contact you shortly.',

    supportTitle: 'Direct Support',
    supportSub: 'Our expert coordinators Zemenu & Tijani are live to assist.',
    supportHours: 'Available via secure channels 24/7',
    btnCall: 'Call Now',

    footerText: 'Helping Businesses Grow Online',
    footerQuickLinks: 'Quick Links',
    footerSocials: 'Social Links',
    footerCopyright: 'Built by Tijani, Full Stack Web Developer'
  },
  am: {
    navHome: 'መነሻ',
    navServices: 'አገልግሎቶች',
    navWork: 'የሰራናቸው ስራዎች',
    navContact: 'ያግኙን',

    heroTitle: 'ቢዝነሶች በኢንተርኔት እንዲያድጉ እናግዛለን',
    heroSub: 'ድረ-ገጾች፣ ዲጂታል ማርኬቲንግ፣ ብራንዲንግ እና የቢዝነስ ማስተዋወቅ ስራዎች - ድርጅትዎ ጎልቶ እንዲወጣ እና እንዲያድግ የተነደፉ።',
    heroTags: ['የድረ-ገጽ ልማት', 'የሶሻል ሚዲያ ማርኬቲንግ', 'ብራንዲንግ (ምልክት)', 'የቢዝነስ ማስተዋወቅ'],
    heroTrust: 'በመላው ኢትዮጵያ የሚገኙ ሆቴሎች፣ ሬስቶራንቶች፣ ክሊኒኮችና ሌሎች ቢዝነሶች ጠንካራ የዲጂታል ተደራሽነት እንዲኖራቸው እናግዛለን።',
    btnStart: 'ፕሮጀክትዎን ይጀምሩ',
    btnWork: 'ስራዎቻችንን ይመልከቱ',

    featuresTitle: 'ለምን ናይል ዲጂታልስን ይመርጣሉ?',
    featResponsive: 'ለሞባይል አመቺ',
    featMultilingual: 'ባለብዙ ቋንቋ ድጋፍ',
    featFastLoading: 'በጣም ፈጣን',
    featSEO: 'ለፍለጋ ሞተሮች የተዘጋጀ (SEO)',
    featWhatsApp: 'የዋትስአፕ ውህደት',
    featCustSupport: 'የደንበኛ ድጋፍ',
    featModernUI: 'ዘመናዊ ዲዛይን (UI/UX)',

    servicesTitle: 'የምንሰጣቸው አገልግሎቶች',
    servicesSubtitle: 'ቢዝነስዎ በዲጂታል ገበያ ውስጥ ተወዳዳሪና ጉልህ እንዲሆን የተነደፉ ዘመናዊ መፍትሄዎች።',
    webDevTitle: 'የድረ-ገጽ ልማት',
    webDevDesc: 'ለሆቴሎች፣ ሬስቶራንቶች፣ ክሊኒኮች፣ ጂሞች፣ ኮንስትራክሽን ድርጅቶች፣ አቅራቢዎች እና ለተለያዩ ቢዝነሶች የሚሆኑ ድረ-ገጾችን እንሰራለን።',
    smmTitle: 'የሶሻል ሚዲያ ማርኬቲንግ',
    smmDesc: 'የተመልካች ቁጥርዎን ያሳድጉ እንዲሁም የቢዝነስዎን ታዋቂነት በዋና ዋና ማህበራዊ ሚዲያዎች ላይ ይጨምሩ።',
    reviewsTitle: 'የቢዝነስ ግምገማዎችና ማስተዋወቅ',
    reviewsDesc: 'ቢዝነስዎ ሰፊ ተደራሽነት እንዲያገኝ፣ እውነተኛ አዎንታዊ ግብረመልስ እንዲያከማች እና ዲጂታል እምነትን እንዲገነባ እናግዛለን።',
    brandingTitle: 'ብራንዲንግ',
    brandingDesc: 'የቢዝነስዎን መታወቂያ ያሻሽሉ፣ ልዩ የመለያ ቀለሞችን እና ውበትን በመፍጠር የመስመር ላይ ገጽታዎን ያሳምሩ።',

    workTitle: 'የሰራናቸው ስራዎች',
    workSubtitle: 'ጥራትና ጥንቃቄ በተሞላበት መንገድ ለቢዝነሶች የሰራናቸውን ዘመናዊ ድረ-ገጾች እዚህ ይመልከቱ።',
    workAll: 'ሁሉም ስራዎች',
    workHotels: 'ሆቴሎች',
    workRestaurants: 'ሬስቶራንቶችና ካፌዎች',
    workHealthcare: 'የጤና ተቋማት',
    workOther: 'ሌሎች ቢዝነሶች',
    workFeatured: 'ዋና የሰራነው ስራ',
    btnViewProject: 'ድረ-ገጹን ጎብኝ',

    contactTitle: 'ፕሮጀክትዎን አሁን ይጀምሩ',
    contactSubtitle: 'የድርጅትዎን የመስመር ላይ ተደራሽነት ለማሳደግ እንዴት ልንረዳዎ እንደምንችል ይንገሩን። በጥቂት ደቂቃዎች ውስጥ ምላሽ እንሰጣለን።',
    formName: 'ሙሉ ስም',
    formNamePl: 'የእርስዎ ስም',
    formBusiness: 'የድርጅት ስም',
    formBusinessPl: 'ምሳሌ፦ ይጋንዳ ሆቴል',
    formService: 'የሚፈልጉት አገልግሎት',
    formServiceSelect: 'አገልግሎት ይምረጡ',
    formDesc: 'ስለ ድርጅቱ አጭር መግለጫ',
    formDescPl: 'ስለ ድርጅትዎ አጭር መግለጫ እዚህ ይጻፉ...',
    formDetails: 'ተጨማሪ ዝርዝሮች',
    formDetailsPl: 'ጨምሮ ምን አይነት ገጾች ወይም ክፍሎች እንዲኖሩት ይፈልጋሉ?',
    btnSend: 'ጥያቄዬን ላክ',
    btnWhatsAppForm: 'በዋትስአፕ ያግኙን',
    successMessage: 'ጥያቄዎ በተሳካ ሁኔታ ተልኳል! በቅርቡ እናገኝዎታለን።',

    supportTitle: 'ቀጥታ ድጋፍ',
    supportSub: 'አስተባባሪዎቻችን ዘመኑ እና ቲጃኒ አሁን መስመር ላይ ናቸው።',
    supportHours: 'በቀጥታ መስመሮች 24/7 ዝግጁ ነን',
    btnCall: 'አሁን ይደውሉ',

    footerText: 'ቢዝነሶች በኢንተርኔት እንዲያድጉ እናግዛለን',
    footerQuickLinks: 'ፈጣን ማገናኛዎች',
    footerSocials: 'የማህበራዊ ሚዲያ ሊንኮች',
    footerCopyright: 'የተገነባው በ ቲጃኒ፣ ፉል ስታክ ዌብ ዲቨሎፐር'
  },
  om: {
    navHome: 'Ka\'umsa',
    navServices: 'Tajaajiloota',
    navWork: 'Hojii Keenya',
    navContact: 'Qunnamtii',

    heroTitle: 'Daldaloota Toora Intaranetaa Irratti Gurguddisuu',
    heroSub: 'Weebsaayitiilee piroofeeshinaalaa, beeksisa dijitaalaa, branding fi babal\'ina daldalaa kan daldalli keessan adda ta\'ee akka guddatu gochuuf qophaa\'an.',
    heroTags: ['Weebsaayitoota Qopheessuu', 'Beeksisa Miidiyaa Hawaasummaa', 'Branding (Moggaasa)', 'Beeksisa Daldalaa'],
    heroTrust: 'Hoteelotni, restoraantotni, kilinikotni, fi daldalotni guutuu Itiyoophiyaa keessatti dandeettii dijitaalaa isaanii cimsuuf ni gargaarra.',
    btnStart: 'Piroojektii Keessan Jalqabaa',
    btnWork: 'Hojii Keenya Ilaalaa',

    featuresTitle: 'Maaliif Nile Digitals Filattu?',
    featResponsive: 'Moobaayilaaf Mijataa',
    featMultilingual: 'Deeggarsa Afaan Hedduu',
    featFastLoading: 'Saffisa Ol-aanaa',
    featSEO: 'Gara Ful-duraa (SEO)',
    featWhatsApp: 'Waliin hidhamuu WhatsApp',
    featCustSupport: 'Deeggarsa Maamilaa',
    featModernUI: 'Miidhagina Ammayyaa (UI/UX)',

    servicesTitle: 'Tajaajiloota Keenya',
    servicesSubtitle: 'Malleen daldala keessan gabaa dijitaalaa keessatti adda ta`uu fi akka guddatu gochuuf qophaa\'an.',
    webDevTitle: 'Weebsaayitoota Qopheessuu',
    webDevDesc: 'Weebsaayitoota dhuunfaa hoteelota, restoraantota, kilinikota, jimoof, waldaalee ijaarsaa fi daldalootaaf ni hojjenna.',
    smmTitle: 'Beeksisa Miidiyaa Hawaasummaa',
    smmDesc: 'Milaatota keessan dabalaa, mul\'achuu daldala keessanii karaa miidiyaalee hawaasummaa guddisaa.',
    reviewsTitle: 'Gamaggama & Beeksisa Daldalaa',
    reviewsDesc: 'Maamiloonni daldala keessan akka beekan gochuu fi dhugoomina dijitaalaa ijaaruuf daldala keessan gargaarra.',
    brandingTitle: 'Branding (Moggaasa)',
    brandingDesc: 'Eenyummaa daldala keessanii fi toora intaranetaa keessanii bifa bareedaa fi ammayyaawaa ta\'een fooyyeessaa.',

    workTitle: 'Hojii Keenya',
    workSubtitle: 'Ilaalcha piroojektota qulqullina olaanaa qaban, daldalootaaf bareedisnee qopheesine hojjenne goobnaa.',
    workAll: 'Hojii Hundumaa',
    workHotels: 'Hoteelota',
    workRestaurants: 'Restoraantota & Kaaffeewwan',
    workHealthcare: 'Kilinikoota Fayyaa',
    workOther: 'Daldaloota Biroo',
    workFeatured: 'Hojii Adda Tahe',
    btnViewProject: 'Piroojektii Ilaali',

    contactTitle: 'Piroojektii Jalqabaa',
    contactSubtitle: 'Akkaataa dandeettii toora intaranetaa keessanii ol guddisuu dandeenyu nu beeksisaa. Daqiiqaa muraasa keessatti deebii argattu.',
    formName: 'Maqaa Guutuu',
    formNamePl: 'Maqaa Keessan',
    formBusiness: 'Maqaa Daldalaa',
    formBusinessPl: 'fkn. Yiganda Hotel',
    formService: 'Tajaajila Barbaadamu',
    formServiceSelect: 'Tajaajila Filadhu',
    formDesc: 'Ibsa Daldalaa',
    formDescPl: 'Waa\'ee daldala keessanii gabaabsee nuu ibsaa...',
    formDetails: 'Ibsa Dabalataa',
    formDetailsPl: 'Fuula dabalataa ykn kutaalee dabalataa maalfaa barbaaddu?',
    btnSend: 'Ergaa Ergi',
    btnWhatsAppForm: 'Nu Qunnamaa',
    successMessage: 'Inquiry Keessan Milkaa\'inaan Ergameera! Dhiyeenyatti isin qunnamna.',

    supportTitle: 'Deeggarsa Kallatti',
    supportSub: 'Gurgurtoonni keenya Zemenu fi Tijani akka isin gargaaraniif toora irra jiru.',
    supportHours: 'Kallattiin dandeetti quunnamtii 24/7 qophiidha',
    btnCall: 'Amma Bilbili',

    footerText: 'Daldaloota Toora Intaranetaa Irratti Gurguddisuu',
    footerQuickLinks: 'Liinkii Saffisaa',
    footerSocials: 'Qunnamtii Hawaasaa',
    footerCopyright: 'Tijaniin, Guddisaa Weebsaayitii Guutuutiin kan ijaarame'
  },
  ti: {
    navHome: 'መበገሲ',
    navServices: 'ኣገልግሎታት',
    navWork: 'ስራሕትና',
    navContact: 'ርክብ',

    heroTitle: 'ትካላት ብመስመር ክዓብዩ ምሕጋዝ',
    heroSub: 'ፕሮፌሽናል መርበብ ሓበሬታ፣ ዲጂታል ማርኬቲንግ፣ ብራንዲንግን ምልላይን - ትካልኩም ፍሉይን ዕዉትን ክኸውን ዝተዳለዉ።',
    heroTags: ['ምድላው መርበብ ሓበሬታ', 'ናይ ማሕበራዊ ሚዲያ ማርኬቲንግ', 'ብራንዲንግ (ምልክት)', 'ምልላይ ቢዝነስ'],
    heroTrust: 'ኣብ መላእ ኢትዮጵያ ዝርከቡ ሆቴላት፣ ሬስቶራንታት፣ ክሊኒካትን ትካላትን ዝሓየለ ዲጂታል ተበጻሕነት ክህልዎም ንሕግዝ።',
    btnStart: 'ፕሮጀክትኩም ጀምሩ',
    btnWork: 'ስራሕትና ርኣዩ',

    featuresTitle: 'ስለምንታይ ናይል ዲጂታልስ ይመርጹ?',
    featResponsive: 'ንሞባይል ዝጥዕም',
    featMultilingual: 'ናይ ብዙሕ ቋንቋ ሓገዝ',
    featFastLoading: 'ቀልጣፋ ኣሰራርሓ',
    featSEO: 'ንፍለጣ ሞተር ዝተዳለወ (SEO)',
    featWhatsApp: 'ናይ ዋትስኣፕ ምትእስሳር',
    featCustSupport: 'ናይ ደንበኛ ሓገዝ',
    featModernUI: 'ዘመናዊ ንድፊ (UI/UX)',

    servicesTitle: 'ኣገልግሎታትና',
    servicesSubtitle: 'ትካልኩም ኣብ ቴክኖሎጂያዊ ዕዳጋ ፍሉይን ዕዉትን ክኸውን ዝሕግዙ ዘመናዊ መፋትሕ።',
    webDevTitle: 'ምድላው መርበብ ሓበሬታ',
    webDevDesc: 'ንሆቴላት፣ ሬስቶራንታት፣ ክሊኒካት፣ ጂማት፣ ህንጻ ትካላት፣ ቀረብትን ኣብ ዝተፈላለዩ ቢዝነሳትን ዘገልግሉ ዝተፈላለዩ መርበብ ሓበሬታታት ንሰርሕ።',
    smmTitle: 'ናይ ማሕበራዊ ሚዲያ ማርኬቲንግ',
    smmDesc: 'ቁጽሪ ተኸታተልትኹም ኣዕብዩ፣ ተፈላጥነት ትካልኩም ኣብ ፍሉጣት ማሕበራዊ ሚዲያታት ወስኹ።',
    reviewsTitle: 'ግምገማታትን ምልላይ ቢዝነስን',
    reviewsDesc: 'ቢዝነስኩም ዝርዝር ተበጻሕነት ክረክብ፣ ትኽክለኛ አወንታዊ ግብረ-መልሲ ክእክብን ዘተኣማምን ዲጂታል ርክብ ክሰርሕን ነግዝ።',
    brandingTitle: 'ብራንዲንግ (ምልክት)',
    brandingDesc: 'መንነት ቢዝነስኩም ኣመሓይሹ፣ ፍሉይ ውቁብ መለለዪ ሕብርታትን ንድፍታትን ብምፍጣር ናይ ኢንተርኔት ገጽታኹም ኣሳምዩ።',

    workTitle: 'ስራሕትና',
    workSubtitle: 'ነቶም ፍሉያት ቢዝነሳት ብጥንቃቐን ብሉጽ ንድፍን ዘዳለናዮም ዘመናዊ መርበብ ሓበሬታታት እዚ ይመልከቱ።',
    workAll: 'ኩሎም ስራሕቲ',
    workHotels: 'ሆቴላት',
    workRestaurants: 'ሬስቶራንታትን ካፌታትን',
    workHealthcare: 'ክሊኒካት',
    workOther: 'ካልኦት ቢዝነሳት',
    workFeatured: 'ብሉጽ ዝተሰርሐ ስራሕ',
    btnViewProject: 'መርበብ ሓበሬታ ርኣይ',

    contactTitle: 'ፕሮጀክትኹም ሕጂ ጀምሩ',
    contactSubtitle: 'ናይ ትካልኩም ዲጂታል ተበጻሕነት ንምዕባይ ብከመይ ክንሕግዘኩም ከምእንኽእል ኣፍልጡና። ኣብ ውሑድ ደቒቕ ክምልሰልኩም ኢና።',
    formName: 'ምሉእ ስም',
    formNamePl: 'ስምኩም',
    formBusiness: 'ሽም ትካል',
    formBusinessPl: 'ምሳሌ፦ ይጋንዳ ሆቴል',
    formService: 'ዝድለ ኣገልግሎት',
    formServiceSelect: 'ኣገልግሎት መርጽ',
    formDesc: 'ሓጺር መግለጺ ትካል',
    formDescPl: 'ስለ ትካልኩም ሓጺር መግለጺ ኣብዚ ጽሓፉ...',
    formDetails: 'ተወሳኺ ዝርዝር',
    formDetailsPl: 'እንታይ ዓይነት ገጻት ወይ ክፋላት ክህልውዎ ትደልዩ?',
    btnSend: 'ሕቶይ ለአኽ',
    btnWhatsAppForm: 'ብዋትስኣፕ ርኸቡና',
    successMessage: 'ሕቶኹም ብሰላም ተላኢኹ ኣሎ! ቀረባ ግዜ ክንረኽበኩም ኢና።',

    supportTitle: 'ቀጥታ ደገፍ',
    supportSub: 'ኣተሓባበርትና ዘመኑን ቲጃኒን ሕጂ ኣብ መስመር ይርከቡ።',
    supportHours: 'ብቀጥታ ርክብ 24/7 ድሉዋት ኢና',
    btnCall: 'ሕጂ ደውሉ',

    footerText: 'ትካላት ብመስመር ክዓብዩ ምሕጋዝ',
    footerQuickLinks: 'ቅልጡፍ መላግቦታት',
    footerSocials: 'ማሕበራዊ ሚዲያታት',
    footerCopyright: 'ዝተሃነጸ ብ ቲጃኒ፣ ፉል ስታክ ዌብ ዲቨሎፐር'
  }
};

export interface ProjectCard {
  id: string;
  name: string;
  category: 'hotels' | 'restaurants' | 'healthcare' | 'other';
  industry: string;
  industryAm: string;
  industryOm: string;
  industryTi: string;
  url: string;
  imageUrl: string;
  prominent: boolean; // Makes hotels, restaurants, and dental clinic visually larger
}

export const projectsData: ProjectCard[] = [
  // Hotels (Prominent)
  {
    id: 'yiganda-hotel',
    name: 'Yiganda Hotel',
    category: 'hotels',
    industry: 'Lakeside Boutique Hotel',
    industryAm: 'የሀይቅ ዳር ቡቲክ ሆቴል',
    industryOm: 'Hoteela Lakeside',
    industryTi: 'ሆቴል ሓይቅ ገጽ',
    url: 'https://yigandamainsample.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?q=70&w=1000&auto=format&fit=crop',
    prominent: true
  },
  {
    id: 'homland-hotel',
    name: 'Homland Hotel',
    category: 'hotels',
    industry: 'Business & Resort Hotel',
    industryAm: 'የቢዝነስና የሪዞርት ሆቴል',
    industryOm: 'Hoteela Resort fi Bisnasii',
    industryTi: 'ሪዞርትን ቢዝነስን ሆቴል',
    url: 'https://homland-hot.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?q=70&w=1000&auto=format&fit=crop',
    prominent: true
  },
  // Restaurants & Cafes (Prominent)
  {
    id: 'olive-restaurant',
    name: 'Olive Restaurant',
    category: 'restaurants',
    industry: 'Modern Fine Dining',
    industryAm: 'ዘመናዊ የቅንጦት ሬስቶራንት',
    industryOm: 'Nyaata Fine Dining Ammayyaa',
    industryTi: 'ዘመናዊ ሬስቶራንት',
    url: 'https://olive-restaurant.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=70&w=1000&auto=format&fit=crop',
    prominent: true
  },
  {
    id: 'velert-cafe',
    name: 'Velert Cake & Cafe',
    category: 'restaurants',
    industry: 'Premium Pastry & Espresso Bar',
    industryAm: 'የተመረጡ ኬኮችና ኤስፕሬሶ ባር',
    industryOm: 'Keekii fi Kaaffee Premium',
    industryTi: 'ብሉጽ ብስኩትን ኤስፕሬሶን ካፌ',
    url: 'https://velert-cafe-fi.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1559622214-f8a98509653a?q=70&w=1000&auto=format&fit=crop',
    prominent: true
  },
  // Healthcare (Prominent)
  {
    id: 'dental-clinic',
    name: 'Dental Clinic',
    category: 'healthcare',
    industry: 'Professional Aesthetic Dentistry',
    industryAm: 'ፕሮፌሽናል የጥርስ ህክምና ክሊኒክ',
    industryOm: 'Kilinika Ilkaan Piroofeeshinaalaa',
    industryTi: 'ሆስፒታል ክሊኒክ ስናን',
    url: 'https://dental-figma.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=70&w=1000&auto=format&fit=crop',
    prominent: true
  },
  // Other Businesses (Subtle / Standard Card size)
  {
    id: 'gym-website',
    name: 'Active Fitness Gym',
    category: 'other',
    industry: 'Wellness & Gym Club',
    industryAm: 'የአካል ብቃት እንቅስቃሴና ስፖርት ማዕከል',
    industryOm: 'Jimii fi Isportii Club',
    industryTi: 'ጂምን ሃለዋት ስፖርትን',
    url: 'https://gymsample221.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=70&w=600&auto=format&fit=crop',
    prominent: false
  },
  {
    id: 'computer-supplier',
    name: 'BHAIR Computers',
    category: 'other',
    industry: 'Enterprise IT & Computer Hardware',
    industryAm: 'የኮምፒውተርና የሃርድዌር አቅራቢ',
    industryOm: 'Qopheessaa Hardware fi IT',
    industryTi: 'ቀራቢ ኮምፒውተራትን ሃርድዌርን',
    url: 'https://bhair-supply11.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?q=70&w=600&auto=format&fit=crop',
    prominent: false
  },
  {
    id: 'coffee-shop',
    name: 'Artisanal Coffee Shop',
    category: 'other',
    industry: 'Specialty Coffee Exporter & Cafe',
    industryAm: 'ልዩ የቡና መሸጫና ካፌ',
    industryOm: 'Mana Bunaa fi Kaaffee Specialty',
    industryTi: 'ፍሉይ ቡናን ካፌን',
    url: 'https://coffee-shoptj.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=70&w=600&auto=format&fit=crop',
    prominent: false
  },
  {
    id: 'aether-lounge',
    name: 'Aether Lounge',
    category: 'other',
    industry: 'Premium Lounge & Social Spot',
    industryAm: 'የቅንጦት ላውንጅና ሬስቶራንት',
    industryOm: 'Laawunjii fi Restoraantii Coortu',
    industryTi: 'ብሉጽ ላውንጅን መዘናግዕን',
    url: 'https://aether-lounge.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?q=70&w=600&auto=format&fit=crop',
    prominent: false
  },
  {
    id: 'construction-company',
    name: 'Biniam & Partners',
    category: 'other',
    industry: 'Infrastructure & Construction Engineering',
    industryAm: 'የኮንስትራክሽንና የመሰረተ ልማት ግንባታ',
    industryOm: 'Dhaabbata Ijaarsaa fi Injinaringii',
    industryTi: 'ኮንስትራክሽንን ኢንጂነሪንግን ህንጻ',
    url: 'https://habtamu-ginebeneh-portfolio.netlify.app/',
    imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=70&w=600&auto=format&fit=crop',
    prominent: false
  }
];

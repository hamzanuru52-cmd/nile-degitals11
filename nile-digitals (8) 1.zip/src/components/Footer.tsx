import { Instagram, Send, MessageCircle } from 'lucide-react';
import { Language, translations } from '../types';

interface FooterProps {
  currentLang: Language;
}

export default function Footer({ currentLang }: FooterProps) {
  const t = translations[currentLang];

  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer id="footer" className="bg-[#ebd9c1]/20 border-t border-[#e5dfd3] py-16 px-6 md:px-12 text-left">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-12">
        
        {/* Brand statement column */}
        <div id="footer-brand" className="md:col-span-5 flex flex-col items-start">
          <span className="font-serif text-2xl font-light tracking-wide text-stone-900 mb-4 cursor-pointer" onClick={() => handleScrollTo('home')}>
            NILE <span className="font-sans font-bold text-xs tracking-widest text-[#c5a880]">DIGITALS</span>
          </span>
          <p className="font-sans text-[#44403c] text-xs leading-relaxed max-w-sm font-light mb-6">
            {t.footerText}
          </p>
          <span className="font-mono text-[10px] uppercase font-semibold text-stone-400 tracking-widest">
            Bahir Dar, Ethiopia
          </span>
        </div>

        {/* Quick links column */}
        <div id="footer-links" className="md:col-span-3">
          <h4 className="font-serif text-xs font-semibold uppercase tracking-wider text-stone-900 mb-5">
            {t.footerQuickLinks}
          </h4>
          <ul className="space-y-3 font-sans text-xs">
            <li>
              <button
                id="foot-link-home"
                onClick={() => handleScrollTo('home')}
                className="text-stone-600 hover:text-[#c5a880] transition-colors cursor-pointer"
              >
                {t.navHome}
              </button>
            </li>
            <li>
              <button
                id="foot-link-services"
                onClick={() => handleScrollTo('services')}
                className="text-stone-600 hover:text-[#c5a880] transition-colors cursor-pointer"
              >
                {t.navServices}
              </button>
            </li>
            <li>
              <button
                id="foot-link-work"
                onClick={() => handleScrollTo('work')}
                className="text-stone-600 hover:text-[#c5a880] transition-colors cursor-pointer"
              >
                {t.navWork}
              </button>
            </li>
            <li>
              <button
                id="foot-link-contact"
                onClick={() => handleScrollTo('contact')}
                className="text-stone-600 hover:text-[#c5a880] transition-colors cursor-pointer"
              >
                {t.navContact}
              </button>
            </li>
          </ul>
        </div>

        {/* Social channels column */}
        <div id="footer-socials" className="md:col-span-4 select-none">
          <h4 className="font-serif text-xs font-semibold uppercase tracking-wider text-stone-900 mb-5">
            {t.footerSocials}
          </h4>
          
          {/* Active direct links for both coordinators */}
          <div className="space-y-4 mb-6">
            <div id="zemenu-social">
              <span className="text-[10px] uppercase tracking-wider font-mono text-stone-400 block mb-1">Zemenu</span>
              <div className="flex items-center space-x-3 text-xs font-sans">
                <a
                  href="https://www.instagram.com/era__john"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1.5 text-stone-600 hover:text-[#c5a880] transition-colors font-light"
                >
                  <Instagram className="w-3.5 h-3.5 text-stone-500" />
                  <span>Instagram</span>
                </a>
                <span className="text-stone-300">|</span>
                <a
                  href="https://wa.me/251938322121"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-light text-stone-600 hover:text-[#c5a880] transition-all inline-flex items-center space-x-1"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-stone-500" />
                  <span>WhatsApp</span>
                </a>
                <span className="text-stone-300">|</span>
                <a
                  href="https://t.me/+251938322121"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-light text-stone-600 hover:text-[#c5a880] transition-all inline-flex items-center space-x-1"
                >
                  <Send className="w-3.5 h-3.5 text-stone-500" />
                  <span>Telegram</span>
                </a>
              </div>
            </div>

            <div id="tijani-social">
              <span className="text-[10px] uppercase tracking-wider font-mono text-stone-400 block mb-1">Tijani</span>
              <div className="flex items-center space-x-3 text-xs font-sans">
                <a
                  href="https://www.instagram.com/tijan.h11"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1.5 text-stone-600 hover:text-[#c5a880] transition-colors font-light"
                >
                  <Instagram className="w-3.5 h-3.5 text-stone-500" />
                  <span>Instagram</span>
                </a>
                <span className="text-stone-300">|</span>
                <a
                  href="https://wa.me/251909353838"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-light text-stone-600 hover:text-[#c5a880] transition-all inline-flex items-center space-x-1"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-stone-500" />
                  <span>WhatsApp</span>
                </a>
                <span className="text-stone-300">|</span>
                <a
                  href="https://t.me/tijan_h11"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-light text-stone-600 hover:text-[#c5a880] transition-all inline-flex items-center space-x-1"
                >
                  <Send className="w-3.5 h-3.5 text-stone-500" />
                  <span>Telegram</span>
                </a>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Thin line & clean copy bottom bar */}
      <div id="footer-bottom" className="max-w-7xl mx-auto border-t border-[#e5dfd3] mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="font-sans text-[11px] text-stone-500 font-light">
          © 2026 Nile Digitals — Built by Tijani, Full Stack Web Developer |{' '}
          <a
            href="https://www.instagram.com/tijan.h11"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#c5a880] hover:underline font-normal animate-pulse-slow"
          >
            @tijan.h11
          </a>
        </p>
        <div className="flex items-center space-x-4">
          <span className="font-mono text-[9px] text-stone-400 tracking-widest uppercase">
            All Rights Reserved
          </span>
        </div>
      </div>
    </footer>
  );
}

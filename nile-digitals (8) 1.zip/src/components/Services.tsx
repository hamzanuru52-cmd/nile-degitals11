import { Laptop, Megaphone, Star, Landmark } from 'lucide-react';
import { Language, translations } from '../types';

interface ServicesProps {
  currentLang: Language;
}

export default function Services({ currentLang }: ServicesProps) {
  const t = translations[currentLang];

  const services = [
    {
      id: 'webdev',
      icon: Laptop,
      title: t.webDevTitle,
      desc: t.webDevDesc,
      num: '01'
    },
    {
      id: 'smm',
      icon: Megaphone,
      title: t.smmTitle,
      desc: t.smmDesc,
      num: '02'
    },
    {
      id: 'reviews',
      icon: Star,
      title: t.reviewsTitle,
      desc: t.reviewsDesc,
      num: '03'
    },
    {
      id: 'branding',
      icon: Landmark,
      title: t.brandingTitle,
      desc: t.brandingDesc,
      num: '04'
    }
  ];

  return (
    <section
      id="services"
      className="bg-[#faf8f5] py-24 px-6 md:px-12 border-b border-[#e5dfd3]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header Block reminiscent of fine hotel brochures */}
        <div id="services-intro" className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
          <div className="max-w-xl text-left">
            <span className="font-mono text-xs font-semibold tracking-widest text-[#c5a880] uppercase block mb-3">
              02 / PROFESSIONAL SERVICES
            </span>
            <h2 className="font-serif text-3.5xl sm:text-4xl lg:text-5xl text-[#1c1917] font-light tracking-tight">
              {t.servicesTitle}
            </h2>
          </div>
          <div className="max-w-md text-left">
            <p className="font-sans text-stone-600 text-sm font-light leading-relaxed">
              {t.servicesSubtitle}
            </p>
          </div>
        </div>

        {/* 4 Cards Grid */}
        <div
          id="services-grid"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {services.map((srv) => {
            const IconComp = srv.icon;
            return (
              <div
                key={srv.id}
                id={`service-card-${srv.id}`}
                className="group relative bg-[#fcfaf7] border border-[#e5dfd3]/80 p-8 flex flex-col items-start text-left min-h-[320px] rounded-xs transition-all duration-500 hover:shadow-lg hover:border-[#c5a880] hover:translate-y-[-4px] overflow-hidden"
              >
                {/* Micro Gold Accent Bar */}
                <div className="absolute top-0 left-0 w-full h-[1px] bg-[#e5dfd3] group-hover:bg-[#c5a880] transition-colors duration-500" />

                {/* Card Number */}
                <span className="font-mono text-[11px] font-semibold text-stone-400 group-hover:text-[#c5a880] tracking-widest transition-colors duration-300 mb-8 block">
                  {srv.num}
                </span>

                {/* Icon wrapper */}
                <div className="p-3 bg-stone-100 rounded-xs mb-6 group-hover:bg-[#f0ece3] transition-colors duration-300">
                  <IconComp className="w-5 h-5 text-stone-700 group-hover:text-[#c5a880] transition-colors duration-300" />
                </div>

                {/* Service Title */}
                <h3 className="font-serif text-xl text-[#1c1917] font-medium tracking-wide mb-3">
                  {srv.title}
                </h3>

                {/* Service Description */}
                <p className="font-sans text-stone-600 text-xs sm:text-[13px] leading-relaxed font-light mt-auto">
                  {srv.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

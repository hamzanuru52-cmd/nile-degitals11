import { useEffect, useState } from 'react';
import { ChevronRight, ArrowRight } from 'lucide-react';
import { Language, translations } from '../types';

import hotelHero from '../assets/images/hotel_hero_1781078696850.png';
import restaurantHero from '../assets/images/restaurant_hero_1781078712723.png';
import dentalHero from '../assets/images/dental_hero_1781078728023.png';

interface HeroProps {
  currentLang: Language;
}

// Custom-generated assets saved in turn 1
const slides = [
  {
    image: hotelHero,
    industry: 'Luxury Hotel Website',
    industryAm: 'የቅንጦት ሆቴል ገጽ',
    industryOm: 'Weebsaayiti Hoteela Qulqulluu',
    industryTi: 'ብሉጽ መርበብ ሓበሬታ ሆቴል',
    num: '01'
  },
  {
    image: restaurantHero,
    industry: 'Modern Restaurant Website',
    industryAm: 'ዘመናዊ የሬስቶራንት ገጽ',
    industryOm: 'Weebsaayiti Restoraanti Ammayyaa',
    industryTi: 'ዘመናዊ መርበብ ሓበሬታ ሬስቶራንት',
    num: '02'
  },
  {
    image: dentalHero,
    industry: 'Professional Dental Clinic Website',
    industryAm: 'ባለሙያ የጥርስ ህክምና ገጽ',
    industryOm: 'Weebsaayiti Kilinika Ilkaanii',
    industryTi: 'መርበብ ሓበሬታ ክሊኒክ ስናን',
    num: '03'
  }
];

export default function Hero({ currentLang }: HeroProps) {
  const [activeSlide, setActiveSlide] = useState(0);
  const t = translations[currentLang];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 6000); // Elegant 6-second transition rhythm
    return () => clearInterval(interval);
  }, []);

  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const currentSlide = slides[activeSlide];
  const slideIndustryName = (() => {
    switch (currentLang) {
      case 'am': return currentSlide.industryAm;
      case 'om': return currentSlide.industryOm;
      case 'ti': return currentSlide.industryTi;
      default: return currentSlide.industry;
    }
  })();

  return (
    <section
      id="home"
      className="relative h-screen w-full overflow-hidden flex items-center justify-center bg-stone-900"
    >
      {/* Background Images with smooth absolute fading transitions */}
      <div className="absolute inset-0 z-0">
        {slides.map((slide, index) => {
          const isActive = index === activeSlide;
          return (
            <div
              key={slide.image}
              className={`absolute inset-0 transition-opacity duration-1500 ease-in-out ${
                isActive ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <img
                src={slide.image}
                alt={slide.industry}
                loading={index === 0 ? "eager" : "lazy"}
                fetchPriority={index === 0 ? "high" : "low"}
                decoding="async"
                className="w-full h-full object-cover scale-105 transition-transform duration-10000 ease-out"
                style={{
                  transform: isActive ? 'scale(1.02)' : 'scale(1.08)'
                }}
                referrerPolicy="no-referrer"
              />
              {/* Premium dark bronze overlay for high legibility */}
              <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/45 to-black/60" />
            </div>
          );
        })}
      </div>

      {/* Main Content Card Container */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-12 flex flex-col items-start text-left mt-16">
        {/* Industry Active Tag */}
        <div id="slide-tag" className="flex items-center space-x-3 mb-6 animate-fade-in">
          <span className="font-mono text-xs font-semibold text-[#c5a880] tracking-widest uppercase">
            {currentSlide.num}
          </span>
          <div className="w-12 h-[1px] bg-stone-500/50" />
          <span className="font-sans text-xs text-stone-300 tracking-wider font-light uppercase">
            {slideIndustryName}
          </span>
        </div>

        {/* Big Premium Editorial Serif Headline */}
        <h1
          id="hero-headline"
          className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-[#fdfbf7] font-extralight tracking-tight leading-[1.08] max-w-4xl opacity-0 animate-[fadeIn_0.8s_ease-out_forwards]"
        >
          {t.heroTitle.split(' ').map((word, i) => {
            // Gold accent to word 'Grow' or corresponding translated key (e.g. ማደግ, Guddachuu, ክዓብዩ)
            const targetWords = ['Grow', 'ማደግ', 'ያድጉ', 'Guddachuu', 'ክዓብዩ'];
            const isMatch = targetWords.some((target) => word.includes(target));
            return (
              <span key={i} className={isMatch ? 'text-[#c5a880] font-normal italic' : ''}>
                {word}{' '}
              </span>
            );
          })}
        </h1>

        {/* Small Feature Tags Below Headline */}
        <div 
          id="hero-tags" 
          className="flex flex-wrap gap-2 sm:gap-3 mt-6 mb-2 opacity-0 animate-[fadeIn_1s_ease-out_0.2s_forwards]"
        >
          {t.heroTags.map((tag, i) => (
            <span 
              key={i} 
              className="font-sans text-[10px] sm:text-xs text-stone-300 tracking-wider font-light uppercase border border-stone-100/10 hover:border-[#c5a880]/40 px-3 py-1.5 rounded-full bg-stone-950/25 backdrop-blur-xs transition-all cursor-default"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Subtitle */}
        <p
          id="hero-subtitle"
          className="font-sans text-stone-300 text-base sm:text-lg md:text-xl max-w-2xl font-light leading-relaxed mt-4 mb-8 opacity-0 animate-[fadeIn_1s_ease-out_0.4s_forwards]"
        >
          {t.heroSub}
        </p>

        {/* Call to Actions & Trust Statement Container */}
        <div
          id="hero-actions-container"
          className="w-full flex flex-col items-start space-y-6 opacity-0 animate-[fadeIn_1.2s_ease-out_0.6s_forwards]"
        >
          <div
            id="hero-actions"
            className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 w-full sm:w-auto"
          >
            <button
              id="hero-btn-start"
              onClick={() => handleScrollTo('contact')}
              className="group cursor-pointer bg-[#c5a880] hover:bg-[#b0936b] text-[#1c1917] font-sans font-medium text-sm tracking-wider uppercase px-8 py-4 rounded-sm transition-all duration-300 flex items-center justify-center space-x-2 shadow-md hover:translate-y-[-2px]"
            >
              <span>{t.btnStart}</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              id="hero-btn-work"
              onClick={() => handleScrollTo('work')}
              className="cursor-pointer bg-white/10 hover:bg-white/15 text-white font-sans font-medium text-sm tracking-wider uppercase px-8 py-4 rounded-sm transition-all duration-300 border border-white/20 hover:border-white/40 flex items-center justify-center space-x-1"
            >
              <span>{t.btnWork}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Short Trust Statement */}
          <p
            id="hero-trust-statement"
            className="font-sans text-stone-400 text-xs sm:text-sm font-light leading-relaxed max-w-2xl"
          >
            {t.heroTrust}
          </p>
        </div>
      </div>

      {/* Slider Indicator Bullets */}
      <div id="slide-indicators" className="absolute bottom-8 right-6 md:right-12 z-25 flex items-center space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            id={`indicator-${index}`}
            onClick={() => setActiveSlide(index)}
            className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
              index === activeSlide ? 'w-8 bg-[#c5a880]' : 'w-2 bg-stone-500/60 hover:bg-stone-400'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}

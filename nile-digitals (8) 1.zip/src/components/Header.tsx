import { useState, useEffect } from 'react';
import { Menu, X, Globe, ChevronDown } from 'lucide-react';
import { Language, translations } from '../types';

interface HeaderProps {
  currentLang: Language;
  setLang: (lang: Language) => void;
  activeSection: string;
}

const languagesList = [
  { code: 'en', label: 'English', native: 'English' },
  { code: 'am', label: 'Amharic', native: 'አማርኛ' },
  { code: 'om', label: 'Afaan Oromo', native: 'Afaan Oromo' },
  { code: 'ti', label: 'Tigrinya', native: 'ትግርኛ' }
] as const;

export default function Header({ currentLang, setLang, activeSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const t = translations[currentLang];

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of fixed header
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const navItems = [
    { id: 'home', label: t.navHome },
    { id: 'services', label: t.navServices },
    { id: 'work', label: t.navWork },
    { id: 'contact', label: t.navContact }
  ];

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-[#f4f1ea]/90 backdrop-blur-md border-b border-[#e5dfd3] shadow-xs py-4'
          : 'bg-gradient-to-b from-black/40 to-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Brand Logo - Stylized Editorial Type */}
        <button
          id="btn-logo"
          onClick={() => scrollToSection('home')}
          className="flex flex-col items-start text-left cursor-pointer group"
        >
          <span
            className={`font-serif text-2xl font-light tracking-wide transition-colors duration-300 ${
              isScrolled ? 'text-[#1c1917]' : 'text-white'
            }`}
          >
            NILE <span className="font-sans font-semibold text-xs tracking-[0.2em] text-[#c5a880] ml-1">DIGITALS</span>
          </span>
          <span className="text-[9px] uppercase tracking-[0.15em] text-[#a8a29e] mt-0.5 group-hover:text-[#c5a880] transition-colors duration-300">
            Ethiopia
          </span>
        </button>

        {/* Desktop Navigation */}
        <nav id="desktop-nav" className="hidden md:flex items-center space-x-10">
          <div className="flex items-center space-x-8">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => scrollToSection(item.id)}
                  className={`relative font-sans text-[13px] font-medium tracking-wider uppercase transition-all duration-300 cursor-pointer pb-1 ${
                    isActive
                      ? isScrolled
                        ? 'text-[#c5a880]'
                        : 'text-[#c5a880]'
                      : isScrolled
                      ? 'text-[#44403c] hover:text-[#1c1917]'
                      : 'text-stone-200 hover:text-white'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[1px] bg-[#c5a880]" />
                  )}
                </button>
              );
            })}
          </div>

          <div className="h-4 w-[1px] bg-stone-300/40" />

          {/* Language Selector */}
          <div className="relative">
            <button
              id="lang-selector-btn"
              onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-sm text-xs font-sans tracking-wide border transition-all cursor-pointer ${
                isScrolled
                  ? 'border-[#e4ded5] text-[#1c1917] hover:bg-[#eae4d9]'
                  : 'border-white/20 text-white hover:bg-white/10'
              }`}
            >
              <Globe className="w-3.5 h-3.5 text-[#c5a880]" />
              <span>{languagesList.find((l) => l.code === currentLang)?.native}</span>
              <ChevronDown className={`w-3 h-3 transition-transform duration-300 ${isLangDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {isLangDropdownOpen && (
              <>
                <div
                  id="lang-backdrop"
                  className="fixed inset-0 z-10"
                  onClick={() => setIsLangDropdownOpen(false)}
                />
                <div
                  id="lang-dropdown"
                  className="absolute right-0 mt-2 w-48 bg-[#fdfcfa] border border-[#e5dfd3] rounded-md shadow-lg py-1.5 z-20 animate-fade-in"
                >
                  {languagesList.map((lang) => (
                    <button
                      key={lang.code}
                      id={`lang-opt-${lang.code}`}
                      onClick={() => {
                        setLang(lang.code);
                        setIsLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 text-xs font-sans transition-colors flex items-center justify-between cursor-pointer ${
                        currentLang === lang.code
                          ? 'bg-[#f0ece3] text-[#1c1917] font-semibold'
                          : 'text-stone-600 hover:bg-[#fcfaf5] hover:text-[#1c1917]'
                      }`}
                    >
                      <span>{lang.native}</span>
                      <span className="text-[10px] text-stone-400 font-sans tracking-wider">
                        {lang.label}
                      </span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </nav>

        {/* Mobile Navigation Toggle */}
        <div className="md:hidden flex items-center space-x-4">
          {/* Quick Lang Switcher for mobile inside button to avoid clutter */}
          <div className="relative">
            <button
              id="lang-mobile-btn"
              onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
              className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-sm text-xs font-sans tracking-wide border ${
                isScrolled
                  ? 'border-[#e4ded5] text-[#1c1917]'
                  : 'border-white/20 text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5 text-[#c5a880]" />
              <span className="uppercase">{currentLang}</span>
              <ChevronDown className="w-3 h-3" />
            </button>

            {isLangDropdownOpen && (
              <>
                <div
                  id="lang-mobile-backdrop"
                  className="fixed inset-0 z-10"
                  onClick={() => setIsLangDropdownOpen(false)}
                />
                <div
                  id="lang-mobile-dropdown"
                  className="absolute right-0 mt-2 w-40 bg-[#fdfcfa] border border-[#e5dfd3] shadow-md rounded-md py-1 z-20"
                >
                  {languagesList.map((lang) => (
                    <button
                      key={lang.code}
                      id={`lang-mobile-opt-${lang.code}`}
                      onClick={() => {
                        setLang(lang.code);
                        setIsLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs font-sans ${
                        currentLang === lang.code
                          ? 'bg-[#f0ece3] text-[#1c1917] font-medium'
                          : 'text-[#44403c] hover:bg-[#fcfaf5]'
                      }`}
                    >
                      {lang.native}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <button
            id="mobile-menu-toggle"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`cursor-pointer p-1 rounded-sm focus:outline-hidden ${
              isScrolled ? 'text-[#1c1917]' : 'text-white'
            }`}
            aria-label="Toggle Menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div
          id="mobile-menu-drawer"
          className="md:hidden fixed inset-0 top-[65px] bg-[#f8f6f0] z-40 flex flex-col px-6 py-8 border-t border-[#e5dfd3] animate-fade-in"
        >
          <div className="flex flex-col space-y-5">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-mobile-link-${item.id}`}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-left font-serif text-2xl font-light tracking-wide py-1.5 border-b border-[#eae4d9] transition-all cursor-pointer ${
                    isActive ? 'text-[#c5a880] pl-2 font-medium' : 'text-stone-700'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="mt-auto pb-4 space-y-4 text-center">
            <span className="text-[10px] text-stone-400 uppercase tracking-widest font-mono block">
              Nile Digitals — Addis Ababa
            </span>
          </div>
        </div>
      )}
    </header>
  );
}

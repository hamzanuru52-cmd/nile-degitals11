import { useState, FormEvent, ChangeEvent } from 'react';
import { Send, CheckCircle2, MessageSquareCode, AlertCircle } from 'lucide-react';
import { Language, translations } from '../types';

interface ContactProps {
  currentLang: Language;
}

const localContactEnhancer = {
  en: {
    customOption: "Custom Service / Combo",
    customServiceLabel: "Custom Service (optional)",
    customServicePlaceholder: "e.g., Website + SMMA combined",
    customServiceHint: "Tell us exactly what you need, and we will customize the solution for your business.",
    phoneLabel: "Phone Number (optional)",
    phonePlaceholder: "e.g., +251 911...",
    emailLabel: "Email Address (optional)",
    emailPlaceholder: "e.g., business@example.com",
    trustNote: "We serve clients across all cities in Addis Ababa and all over Ethiopia. Our main base is Bahir Dar, Ethiopia.",
    successText: "Your message has been sent successfully. I’ll get back to you as soon as possible.",
    sendAnother: "Send another inquiry"
  },
  am: {
    customOption: "ብጁ አገልግሎት / ጥምረት",
    customServiceLabel: "ብጁ አገልግሎት (አማራጭ)",
    customServicePlaceholder: "ምሳሌ፡ ድረ-ገጽ + ሶሻል ሚዲያ ማርኬቲንግ",
    customServiceHint: "የሚፈልጉትን በትክክል ይንገሩን፣ ለእርስዎ ቢዝነስ የሚስማማውን መፍትሄ እናዘጋጃለን።",
    phoneLabel: "ስልክ ቁጥር (አማራጭ)",
    phonePlaceholder: "ምሳሌ፡ +251 911...",
    emailLabel: "ኢሜይል አድራሻ (አማራጭ)",
    emailPlaceholder: "ምሳሌ፡ business@example.com",
    trustNote: "በአዲስ አበባ በሁሉም ከተሞች እና በመላው ኢትዮጵያ ደንበኞችን እናገለግላለን። ዋናው ማዕከላችን ባሕር ዳር፣ ኢትዮጵያ ነው።",
    successText: "መልእክትዎ በተሳካ ሁኔታ ተልኳል። በተቻለ ፍጥነት እመለስልዎታለሁ።",
    sendAnother: "ሌላ ጥያቄ ላክ"
  },
  om: {
    customOption: "Tajaajila dhuunfaa / Walitti makaa",
    customServiceLabel: "Tajaajila dhuunfaa (filannoo)",
    customServicePlaceholder: "fkn. Weebsaayiti + SMMA combined",
    customServiceHint: "Wanta isiniif barbaachisu sirriitti nutti himaa, furmaata daldala keessaniif ta'u ni mijeessina.",
    phoneLabel: "Lakkoofsa Bilbilaa (filannoo)",
    phonePlaceholder: "fkn. +251 911...",
    emailLabel: "Teessoo Imooyilii (filannoo)",
    emailPlaceholder: "fkn. business@example.com",
    trustNote: "Miliyyonatti magaalaalee Finfinnee fi guutuu Itiyoophiyaa keessatti maamiloota ni tajaajilla. Basiin keenya inni guddaan Bahir Dar, Itiyoophiyaadha.",
    successText: "Ergaan keessan milkaa'inaan ergameera. Saffisaan isin qunnama.",
    sendAnother: "Ergaa dabalataa ergi"
  },
  ti: {
    customOption: "ፍሉይ ኣገልግሎት / ጥምረት",
    customServiceLabel: "ፍሉይ ኣገልግሎት (ኣማራጭ)",
    customServicePlaceholder: "ምሳሌ፡ መርበብ ሓበሬታ + ሶሻል ሚዲያ",
    customServiceHint: "ነቲ ንስኹም ትደልዩዎ በትኽክል ንገሩና፣ ንሽም ቢዝነስኩም ዝሰማማዕ ፍታሕ ክንዳሉ ኢና።",
    phoneLabel: "ቁጽሪ ስልኪ (ኣማራጭ)",
    phonePlaceholder: "ምሳሌ፡ +251 911...",
    emailLabel: "ኢሜይል ኣድራሻ (ኣማራጭ)",
    emailPlaceholder: "ምሳሌ፡ business@example.com",
    trustNote: "ኣብ ኣዲስ ኣበባ ኣብ ኩለን ከተማታትን ኣብ መላእ ኢትዮጵያን ንደንበኛታትና ነገልግሎ። ዋና መዐስከርና ባህር ዳር፣ ኢትዮጵያ እዩ።",
    successText: "መልእኽትኹም ብሰላም ተላኢኹ ኣሎ። ብዝቐልጠፈ እዋን ክምልሰልኩም እየ።",
    sendAnother: "ካልእ ሕቶ ለአኽ"
  }
};

export default function Contact({ currentLang }: ContactProps) {
  const t = translations[currentLang];
  const loc = localContactEnhancer[currentLang] || localContactEnhancer.en;

  const [formData, setFormData] = useState({
    fullName: '',
    businessName: '',
    phoneNumber: '',
    emailAddress: '',
    serviceNeeded: '',
    customService: '',
    businessDesc: '',
    additionalDetails: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const errorMessages = {
    en: "Something went wrong. Please try again.",
    am: "ችግር አጋጥሟል። እባክዎ እንደገና ይሞክሩ።",
    om: "Rakkoon uumameera. Maaloo irra deebitanii yaalaa.",
    ti: "ጸገም ተፈጢሩ። በጃኹም ድጋሜ ፈትኑ።"
  };

  const servicesList = [
    t.webDevTitle,
    t.smmTitle,
    t.reviewsTitle,
    t.brandingTitle,
    loc.customOption
  ];

  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.serviceNeeded) {
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const response = await fetch("https://formspree.io/f/meewzpqj", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          name: formData.fullName,
          email: formData.emailAddress || "no-email@provided.com",
          subject: formData.businessName ? `Inquiry for ${formData.businessName}` : `Inquiry for Nile Digitals Service`,
          message: `${formData.businessDesc || "No message description provided."}\n\nAdditional Details: ${formData.additionalDetails || "None provided"}`,
          serviceNeeded: formData.serviceNeeded,
          customService: formData.customService || "None",
          phoneNumber: formData.phoneNumber || "None",
          businessName: formData.businessName || "None",
          // Desired display fields inside Formspree Email Layout
          "Full Name": formData.fullName,
          "Email Address": formData.emailAddress,
          "Phone Number": formData.phoneNumber,
          "Business Name": formData.businessName,
          "Service Requested": formData.serviceNeeded,
          "Custom Combo Details": formData.customService,
          "Inquiry Message": formData.businessDesc,
          "Additional Details": formData.additionalDetails
        })
      });

      if (response.ok) {
        setIsSubmitted(true);
        // Clear fields
        setFormData({
          fullName: '',
          businessName: '',
          phoneNumber: '',
          emailAddress: '',
          serviceNeeded: '',
          customService: '',
          businessDesc: '',
          additionalDetails: ''
        });
      } else {
        const errorData = await response.json().catch(() => ({}));
        console.error("Formspree submission failed:", errorData);
        setSubmitError(errorMessages[currentLang] || errorMessages.en);
      }
    } catch (error) {
      console.error("Submission error:", error);
      setSubmitError(errorMessages[currentLang] || errorMessages.en);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Pre-filled WhatsApp string
  const handleWhatsAppInquiry = () => {
    const defaultText = `Hello Nile Digitals! I would like to start a project with you.
- Name: ${formData.fullName || '(Drafting)'}
- Business: ${formData.businessName || '(Drafting)'}
${formData.phoneNumber ? `- Phone: ${formData.phoneNumber}\n` : ''}${formData.emailAddress ? `- Email: ${formData.emailAddress}\n` : ''}- Service: ${formData.serviceNeeded || '(Drafting)'}
${formData.customService ? `- Custom Service Details: ${formData.customService}\n` : ''}- Description: ${formData.businessDesc || '(Drafting)'}`;
    
    const urlEncoded = encodeURIComponent(defaultText);
    // Open default coordinator Zemenu's WhatsApp link
    window.open(`https://wa.me/251938322121?text=${urlEncoded}`, '_blank');
  };

  return (
    <section
      id="contact"
      className="bg-[#faf8f5] py-24 px-6 md:px-12 border-b border-[#e5dfd3]"
    >
      <div className="max-w-7xl mx-auto">
        <div id="contact-outer-grid" className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          
          {/* Typography left column */}
          <div id="contact-side" className="lg:col-span-4 text-left">
            <span className="font-mono text-xs font-semibold tracking-widest text-[#c5a880] uppercase block mb-3">
              04 / NEW INQUIRIES
            </span>
            <h2 className="font-serif text-3.5xl sm:text-4xl lg:text-5xl text-[#1c1917] font-light tracking-tight mb-6">
              {t.contactTitle}
            </h2>
            <p className="font-sans text-stone-650 text-sm font-light leading-relaxed mb-8">
              {t.contactSubtitle}
            </p>

            {/* Quick Contact Info */}
            <div id="coord-small" className="space-y-4 pt-6 border-t border-stone-200">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-[#c5a880] block mb-1">Our Coverage</span>
                <span className="text-xs font-sans text-stone-700 block leading-relaxed">
                  Serving Addis Ababa and all over Ethiopia. Specialized in Nationwide Digital Platforms.
                </span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-[#c5a880] block mb-1">Main Base</span>
                <span className="text-xs font-sans text-stone-700 block text-stone-900 font-medium">Bahir Dar, Ethiopia</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-stone-400 block mb-1">Direct Helpdesk</span>
                <a href="tel:+251938322121" className="text-xs font-sans text-stone-700 hover:text-[#c5a880] transition-colors block font-medium">0938322121 / 0909353838</a>
              </div>
            </div>
          </div>

          {/* Inquiry Form right column */}
          <div id="contact-form-container" className="lg:col-span-8 bg-[#fdfcfa] border border-[#e5dfd3]/85 shadow-xs p-8 md:p-12 rounded-xs">
            {isSubmitted ? (
              <div
                id="success-card-container"
                className="py-12 px-4 text-center animate-fade-in flex flex-col items-center justify-center space-y-6"
              >
                <div className="w-16 h-16 bg-emerald-50 border border-emerald-100 text-emerald-600 rounded-full flex items-center justify-center shadow-xs">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="space-y-3 max-w-lg">
                  <h3 className="font-serif text-2xl font-light text-stone-900 tracking-wide">
                    {currentLang === 'en' ? 'Thank You!' : currentLang === 'am' ? 'እናመሰግናለን!' : currentLang === 'om' ? 'Galatoomaa!' : 'የቐንየልና!'}
                  </h3>
                  <p className="font-sans text-stone-600 text-sm font-light leading-relaxed">
                    {loc.successText}
                  </p>
                </div>
                <button
                  type="button"
                  id="btn-send-another"
                  onClick={() => setIsSubmitted(false)}
                  className="cursor-pointer bg-stone-900 hover:bg-[#c5a880] text-amber-50 hover:text-[#1c1917] font-sans font-semibold text-xs tracking-widest uppercase px-6 py-3.5 rounded-xs transition-all duration-300 shadow-xs"
                >
                  {loc.sendAnother}
                </button>
              </div>
            ) : (
              <>
                {submitError && (
                  <div
                    id="error-banner"
                    className="mb-8 p-4 bg-red-50 border-l-2 border-red-500 text-red-900 flex items-start space-x-3 text-left animate-fade-in"
                  >
                    <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-serif text-sm font-semibold tracking-wide">Submission Error</h4>
                      <p className="text-[11px] text-red-750 font-sans font-light mt-1">{submitError}</p>
                    </div>
                  </div>
                )}

                <form id="inquiry-form" onSubmit={handleSubmit} className="space-y-6 text-left">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Full Name */}
                    <div className="flex flex-col">
                      <label htmlFor="fullName" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                        {t.formName} *
                      </label>
                      <input
                        type="text"
                        id="fullName"
                        name="fullName"
                        required
                        value={formData.fullName}
                        onChange={handleInputChange}
                        placeholder={t.formNamePl}
                        className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all"
                      />
                    </div>

                    {/* Business Name */}
                    <div className="flex flex-col">
                      <label htmlFor="businessName" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                        {t.formBusiness}
                      </label>
                      <input
                        type="text"
                        id="businessName"
                        name="businessName"
                        value={formData.businessName}
                        onChange={handleInputChange}
                        placeholder={t.formBusinessPl}
                        className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all"
                      />
                    </div>
                  </div>

                  {/* Optional Contact Details Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Phone Number */}
                    <div className="flex flex-col">
                      <label htmlFor="phoneNumber" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                        {loc.phoneLabel}
                      </label>
                      <input
                        type="tel"
                        id="phoneNumber"
                        name="phoneNumber"
                        value={formData.phoneNumber}
                        onChange={handleInputChange}
                        placeholder={loc.phonePlaceholder}
                        className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all"
                      />
                    </div>

                    {/* Email Address */}
                    <div className="flex flex-col">
                      <label htmlFor="emailAddress" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                        {loc.emailLabel}
                      </label>
                      <input
                        type="email"
                        id="emailAddress"
                        name="emailAddress"
                        value={formData.emailAddress}
                        onChange={handleInputChange}
                        placeholder={loc.emailPlaceholder}
                        className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all"
                      />
                    </div>
                  </div>

                  {/* Service Needed */}
                  <div className="flex flex-col">
                    <label htmlFor="serviceNeeded" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                      {t.formService} *
                    </label>
                    <div className="relative">
                      <select
                        id="serviceNeeded"
                        name="serviceNeeded"
                        required
                        value={formData.serviceNeeded}
                        onChange={handleInputChange}
                        className="w-full font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all appearance-none cursor-pointer"
                      >
                        <option value="" disabled>{t.formServiceSelect}</option>
                        {servicesList.map((srv, i) => (
                          <option key={i} value={srv}>{srv}</option>
                        ))}
                      </select>
                      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-[#c5a880]">
                        <svg className="fill-current h-3 w-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                          <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* Custom Service (Optional Input) */}
                  <div className="flex flex-col">
                    <label htmlFor="customService" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                      {loc.customServiceLabel}
                    </label>
                    <input
                      type="text"
                      id="customService"
                      name="customService"
                      value={formData.customService}
                      onChange={handleInputChange}
                      placeholder={loc.customServicePlaceholder}
                      className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all"
                    />
                    {(formData.serviceNeeded === loc.customOption || formData.customService.trim() !== '') && (
                      <p className="text-[11px] text-[#c5a880] font-sans italic mt-1.5 animate-fade-in leading-relaxed">
                        “{loc.customServiceHint}”
                      </p>
                    )}
                  </div>

                  {/* Business Description */}
                  <div className="flex flex-col">
                    <label htmlFor="businessDesc" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                      {t.formDesc}
                    </label>
                    <textarea
                      id="businessDesc"
                      name="businessDesc"
                      rows={3}
                      value={formData.businessDesc}
                      onChange={handleInputChange}
                      placeholder={t.formDescPl}
                      className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all resize-none"
                    />
                  </div>

                  {/* Additional Details */}
                  <div className="flex flex-col">
                    <label htmlFor="additionalDetails" className="font-serif text-xs font-medium text-stone-700 tracking-wider uppercase mb-2">
                       {t.formDetails}
                    </label>
                    <textarea
                      id="additionalDetails"
                      name="additionalDetails"
                      rows={2}
                      value={formData.additionalDetails}
                      onChange={handleInputChange}
                      placeholder={t.formDetailsPl}
                      className="font-sans text-xs bg-[#FAF9F6] border border-[#e5dfd3] px-4 py-3 focus:outline-hidden focus:border-[#c5a880] focus:ring-1 focus:ring-[#c5a880] rounded-xs text-[#292524] transition-all resize-none"
                    />
                  </div>

                  {/* Action buttons */}
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
                    <button
                      type="submit"
                      id="btn-submit-inquiry"
                      disabled={isSubmitting}
                      className="flex-1 cursor-pointer bg-stone-900 hover:bg-stone-800 text-amber-50 font-sans font-semibold text-xs tracking-widest uppercase py-4 rounded-xs transition-all duration-300 flex items-center justify-center space-x-2 shadow-xs"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{isSubmitting ? (currentLang === 'en' ? 'Sending...' : currentLang === 'am' ? 'በመላክ ላይ...' : currentLang === 'om' ? 'Ergamaa Jira...' : 'ብምስዳድ ላይ...') : t.btnSend}</span>
                    </button>

                    <button
                      type="button"
                      id="btn-whatsapp-inquiry"
                      onClick={handleWhatsAppInquiry}
                      className="flex-1 cursor-pointer bg-[#25d366]/10 hover:bg-[#25d366]/20 text-[#128c7e] border border-[#25d366]/30 font-sans font-semibold text-xs tracking-widest uppercase py-4 rounded-xs transition-all duration-300 flex items-center justify-center space-x-2"
                    >
                      <MessageSquareCode className="w-3.5 h-3.5 text-[#128c7e]" />
                      <span>{t.btnWhatsAppForm}</span>
                    </button>
                  </div>

                  {/* Real-time Location Trust note under contact form */}
                  <div className="pt-6 border-t border-[#e5dfd3]/60 text-center mt-6">
                    <p className="font-sans text-[11px] text-stone-500 font-light leading-relaxed">
                      {loc.trustNote}
                    </p>
                  </div>
                </form>
              </>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}

import { useState } from 'react';
import { ExternalLink, Filter } from 'lucide-react';
import { Language, translations, projectsData, ProjectCard } from '../types';

interface WorkProps {
  currentLang: Language;
}

type FilterCategory = 'all' | 'hotels' | 'restaurants' | 'healthcare' | 'other';

export default function Work({ currentLang }: WorkProps) {
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('all');
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);
  const t = translations[currentLang];

  const filterTabs = [
    { key: 'all' as FilterCategory, label: t.workAll },
    { key: 'hotels' as FilterCategory, label: t.workHotels },
    { key: 'restaurants' as FilterCategory, label: t.workRestaurants },
    { key: 'healthcare' as FilterCategory, label: t.workHealthcare },
    { key: 'other' as FilterCategory, label: t.workOther }
  ];

  // Projects filtered by category
  const filteredProjects = projectsData.filter((proj) => {
    if (activeFilter === 'all') return true;
    return proj.category === activeFilter;
  });

  return (
    <section
      id="work"
      className="bg-[#f5f2e9] py-24 px-6 md:px-12 border-b border-[#e5dfd3]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div id="work-header" className="max-w-3xl mb-16 text-left">
          <span className="font-mono text-xs font-semibold tracking-widest text-[#c5a880] uppercase block mb-3">
            03 / SELECTED WRKS OR CASE STUDIES
          </span>
          <h2 className="font-serif text-3.5xl sm:text-4xl lg:text-5xl text-[#1c1917] font-light tracking-tight mb-4">
            {t.workTitle}
          </h2>
          <p className="font-sans text-stone-600 text-sm font-light max-w-xl leading-relaxed">
            {t.workSubtitle}
          </p>
        </div>

        {/* Filter Navigation Tabs */}
        <div
          id="work-filters"
          className="flex flex-wrap items-center gap-2 mb-12 pb-2 border-b border-stone-300/40"
        >
          <div className="flex items-center text-stone-400 mr-4 py-2">
            <Filter className="w-3.5 h-3.5 mr-2 text-[#c5a880]" />
            <span className="font-mono text-[10px] uppercase tracking-wider font-semibold">Filter:</span>
          </div>

          {filterTabs.map((tab) => (
            <button
              key={tab.key}
              id={`filter-tab-${tab.key}`}
              onClick={() => setActiveFilter(tab.key)}
              className={`font-sans text-xs tracking-wider uppercase px-4 py-2 rounded-sm transition-all duration-300 cursor-pointer ${
                activeFilter === tab.key
                  ? 'bg-stone-800 text-amber-50 font-medium'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Responsive Multi-Column Gallery Grid */}
        <div
          id="work-gallery-grid"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {filteredProjects.map((proj) => {
            const isProminent = proj.prominent;
            const cardIndustry = (() => {
              switch (currentLang) {
                case 'am': return proj.industryAm;
                case 'om': return proj.industryOm;
                case 'ti': return proj.industryTi;
                default: return proj.industry;
              }
            })();

            return (
              <div
                key={proj.id}
                id={`project-card-${proj.id}`}
                className="group relative overflow-hidden bg-stone-900 border border-stone-200/10 h-[340px] flex flex-col justify-end transition-all duration-500 rounded-xs hover:shadow-xl hover:translate-y-[-4px]"
                onMouseEnter={() => setHoveredCard(proj.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                {/* Image Element */}
                <div className="absolute inset-0 overflow-hidden z-0">
                  <img
                    src={proj.imageUrl}
                    alt={proj.name}
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover transition-transform duration-[6000ms] ease-out group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  {/* Overlay vignette */}
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/95 via-stone-950/40 to-black/20" />
                </div>

                {/* Left/Right Top Tags */}
                {isProminent && (
                  <div className="absolute top-4 left-4 z-10">
                    <span className="bg-[#c5a880]/90 text-[9px] font-semibold text-stone-950 tracking-widest uppercase px-2 py-0.5 rounded-sm shadow-sm backdrop-blur-xs">
                      {t.workFeatured}
                    </span>
                  </div>
                )}

                {/* Content Overlay */}
                <div className="relative z-10 p-5 md:p-6 text-left transition-transform duration-300">
                  <span className="font-mono text-[9px] font-bold tracking-widest text-[#c5a880] uppercase block mb-1">
                    {cardIndustry}
                  </span>
                  <h3 className="font-serif text-xl md:text-2xl font-light tracking-wide text-stone-50 mb-3 transition-colors group-hover:text-amber-100">
                    {proj.name}
                  </h3>

                  {/* View Project Action (Direct link to live netlify deployment) */}
                  <div className="flex items-center space-x-3 mt-3 pt-3 border-t border-stone-500/35">
                    <a
                      id={`project-link-${proj.id}`}
                      href={proj.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-2 bg-stone-850 hover:bg-[#c5a880] hover:text-[#1c1917] bg-stone-50/10 text-white font-sans text-xs uppercase tracking-wider px-3.5 py-2.5 rounded-xs transition-all duration-300 font-medium"
                    >
                      <span>{t.btnViewProject}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* Subtle corner detail for luxury branding feel */}
                <div className="absolute bottom-0 right-0 w-8 h-8 pointer-events-none border-b border-r border-[#c5a880]/30 group-hover:border-[#c5a880]/85 transition-all duration-300 transform translate-x-1 translate-y-1" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

import { useState } from 'react';
import { MessageSquare, X, Send, Instagram, HelpCircle, ChevronDown } from 'lucide-react';
import { Language } from '../types';

interface SupportProps {
  currentLang: Language;
}

interface FaqItem {
  q: string;
  a: string | string[];
}

const faqs: Record<Language, FaqItem[]> = {
  en: [
    {
      q: "What services do you offer?",
      a: ["Website Development", "Social Media Marketing", "Business Reviews & Promotion", "Branding"]
    },
    {
      q: "Who do you work with?",
      a: ["Hotels", "Restaurants", "Cafes", "Clinics", "Dental Clinics", "Gyms", "Construction Companies", "Real Estate Companies", "Local Businesses"]
    },
    {
      q: "Do you provide multilingual websites?",
      a: "Yes. We support English, Amharic, Afaan Oromo, and Tigrinya."
    },
    {
      q: "Are your websites mobile-friendly?",
      a: "Yes. All websites are fully responsive across mobile, tablet, laptop, and desktop devices."
    }
  ],
  am: [
    {
      q: "ምን ዓይነት አገልግሎቶችን ትሰጣላችሁ?",
      a: ["የድረ-ገጽ ልማት", "የሶሻል ሚዲያ ማርኬቲንግ", "የቢዝነስ ግምገማዎችና ማስተዋወቅ", "ብራንዲንግ"]
    },
    {
      q: "ከማን ጋር ነው የምትሰሩት?",
      a: ["ሆቴሎች", "ሬስቶራንቶች", "ካፌዎች", "ክሊኒኮች", "የጥርስ ህክምና ክሊኒኮች", "ጂሞች", "የኮንስትራክሽን ድርጅቶች", "ሪል እስቴቶች", "የተለያዩ የአገር ውስጥ ቢዝነሶች"]
    },
    {
      q: "ባለብዙ ቋንቋ ድረ-ገጾችን ታዘጋጃላችሁ?",
      a: "አዎ። እንግሊዝኛ፣ አማርኛ፣ አፋን ኦሮሞ እና ትግሪኛን እንደግፋለን።"
    },
    {
      q: "ድረ-ገጾቻችሁ በስልክ ይሰራሉ?",
      a: "አዎ። ሁሉም ድረ-ገጾቻችን በስልኮች፣ ታብሌቶች፣ ላፕቶፖች እና ኮምፒውተሮች ላይ ሙሉ በሙሉ ተስማሚ ሆነው ይሰራሉ።"
    }
  ],
  om: [
    {
      q: "Tajaajiloota akkamii dhiyeessitu?",
      a: ["Weebsaayiti Qopheessuu", "Beeksisa Miidiyaa Hawaasaa", "Gamaggama & Beeksisa Daldalaa", "Branding (Moggaasa)"]
    },
    {
      q: "Eenyu fa`aa waliin hojjettu?",
      a: ["Hoteelota", "Restoraantota", "Kaaffeewwan", "Kilinikota", "Kilinikoota Ilkaanii", "Jimoota", "Kompanii Ijaarsaa", "Kompanii Real Estate", "Daldaloota Naannoo"]
    },
    {
      q: "Weebsaayiti afaan adda addaa qabu ni gootuu?",
      a: "Eeyyee. Afaan Ingilizii, Amaaraa, Oromoo fi Tigriffa ni deeggarra."
    },
    {
      q: "Weebsaayitiin keessan moobaayilaaf mijataadhaa?",
      a: "Eeyyee. Weebsaayitiwwan hundinuu moobaayila, taableetii, laaptooppii fi deeskitooppii irratti guututti mijatoodha."
    }
  ],
  ti: [
    {
      q: "እንታይ ዓይነት ኣገልግሎታት ትህቡ?",
      a: ["ምድላው መርበብ ሓበሬታ", "ናይ ማሕበራዊ ሚዲያ ማርኬቲንግ", "ግምገማታትን ምልላይ ቢዝነስን", "ብራንዲንግ (ምልክት)"]
    },
    {
      q: "ምስ መን ኢኹም ትሰርሑ?",
      a: ["ሆቴላት", "ሬስቶራንታት", "ካፌታት", "ክሊኒካት", "ክሊኒካት ስናን", "ጂማት", "ናይ ህንጻ ትካላት", "ሪል እስቴት", "የተለያዩ ቢዝነሳት"]
    },
    {
      q: "ናይ ብዙሕ ቋንቋ መርበብ ሓበሬታ ትሰርሑ ዶ?",
      a: "እወ። እንግሊዝኛ፣ ኣምሓርኛ፣ ኦሮምኛን ትግርኛን ንድግፍ ኢና።"
    },
    {
      q: "መርበብ ሓበሬታታትኩም ብስልኪ ይሰርሑ ዶ?",
      a: "እወ። ኩሎም መርበብ ሓበሬታታትና ኣብ ስልኪ፣ ታብሌት፣ ላፕቶፕን ኮምፒውተርን ብሉጽ ኮይኖም ይሰርሑ እዮም።"
    }
  ]
};

const supportTitles = {
  en: {
    title: "Need Information?",
    welcome: "Welcome to Nile Digitals.",
    desc: "We help businesses build a professional online presence through modern websites, digital marketing, branding, and business promotion. You can explore our services, featured projects, and contact form throughout the website.",
    faqSection: "Frequently Asked Questions",
    needMore: "Need more information?",
    moreDesc: "For additional details, custom requests, or business discussions, contact our team directly through Telegram or Instagram.",
    contactZemenu: "Contact Zemenu",
    contactTijani: "Contact Tijani"
  },
  am: {
    title: "መረጃ ይፈልጋሉ?",
    welcome: "እንኳን ወደ ናይል ዲጂታልስ በደህና መጡ።",
    desc: "ቢዝነሶች በዘመናዊ ድረ-ገጾች፣ በዲጂታል ማርኬቲንግ፣ በብራንዲንግ እና በቢዝነስ ማስተዋወቅ አማካኝነት ፕሮፌሽናል የመስመር ላይ ተደራሽነት እንዲኖራቸው እናግዛለን። የአገልግሎቶቻችንን፣ ተጨማሪ ስራዎችን እና የጥያቄ ማቅረቢያ ቅጽን በመላው ድረ-ገጣችን ላይ ማሰስ ይችላሉ።",
    faqSection: "ተደጋግመው የሚጠየቁ ጥያቄዎች",
    needMore: "ተጨማሪ መረጃ ይፈልጋሉ?",
    moreDesc: "ለተጨማሪ ዝርዝሮች፣ ብጁ ጥያቄዎች ወይም የንግድ ውይይቶች ቡድናችንን በቀጥታ በቴሌግራም ወይም በኢንስታግራም ያግኙ።",
    contactZemenu: "ዘመኑን ያግኙ",
    contactTijani: "ቲጃኒን ያግኙ"
  },
  om: {
    title: "Odeeffannoo Barbaadduu?",
    welcome: "Baga gara Nile Digitals nagaan dhuftan.",
    desc: "Daldalootaaf weebsaayiti ammayyaa, beeksisa dijitaalaa, dizaayini dhuunfaa fi beeksisa daldalaatiin toora intaranetaa irratti piroofeeshinaala akka ta`an gargaarra. Fuula keenya irratti tajaajiloota, piroojektota keenya fi unka qunnamtii ilaaluu ni dandeessu.",
    faqSection: "Gaffii fi Deebii Deddeebi`anii Kafataman",
    needMore: "Odeeffannoo dabalataa qabduu?",
    moreDesc: "Bal`ina dabalataa, gaaffii dhuunfaa ykn haasaa daldalaatiif, garee keenya kallattiin Telegram ykn Instagram irratti qunnamaa.",
    contactZemenu: "Zemenu Qunnamaa",
    contactTijani: "Tijani Qunnamaa"
  },
  ti: {
    title: "ሓበሬታ ትደልዩ ዶ?",
    welcome: "እንቋዕ ናይ ናይል ዲጂታልስ ብደሓን መጻእኩም።",
    desc: "ትካላት ብዘመናዊ መርበብ ሓበሬታ፣ ዲጂታል ማርኬቲንግ፣ ብራንዲንግን ምልክት ምስፋሕን ዝበለጸ ተበጻሕነት ክህልዎም ነግዝ። ኣገልግሎትና፣ ስራሕትናን ናይ ርክብ ቅጽን ኣብ መላእ መርበብ ሓበሬታና ክትፍትሹ ትኽእሉ ኢኹም።",
    faqSection: "ተደጋጋሚ ሕቶታትን መልስታትን",
    needMore: "ተወሳኺ ሓበሬታ ትደልዩ ዶ?",
    moreDesc: "ንተወሳኺ ዝርዝር ሓበሬታ፣ ፍሉይ ሕቶታት ወይ ናይ ስራሕ ዘተታት ንጋንታና ብቴሌግራም ወይ ኢንስታግራም ብቀጥታ ኣዘራርብዎም።",
    contactZemenu: "ንዘመኑ ኣዘራርብዎ",
    contactTijani: "ንቲጃኒ ኣዘራርብዎ"
  }
};

export default function Support({ currentLang }: SupportProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);

  const t = supportTitles[currentLang] || supportTitles.en;
  const currentFaqList = faqs[currentLang] || faqs.en;

  const toggleFaq = (index: number) => {
    setActiveFaqIndex(activeFaqIndex === index ? null : index);
  };

  return (
    <div id="support-anchor" className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Expanded Help & Information Center Panel */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            id="support-overlay"
            className="fixed inset-0 z-40 bg-black/10 backdrop-blur-xs"
            onClick={() => setIsOpen(false)}
          />
          
          <div
            id="support-panel"
            className="relative z-50 w-[380px] max-w-[calc(100vw-2rem)] bg-[#fdfcfa] border border-[#e5dfd3] shadow-2xl p-6 mb-4 text-left animate-slide-up rounded-md flex flex-col max-h-[82vh]"
          >
            {/* Panel Static Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[#e5dfd3] shrink-0 mb-4">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-[#faf8f5] border border-[#e5dfd3] rounded-xs">
                  <HelpCircle className="w-4 h-4 text-[#c5a880]" />
                </div>
                <div>
                  <h4 className="font-serif text-base font-semibold text-[#1c1917] tracking-wide">
                    {t.title}
                  </h4>
                  <span className="text-[9px] text-[#c5a880] font-sans tracking-widest uppercase font-medium">
                    Nile Digitals Help Center
                  </span>
                </div>
              </div>
              <button
                id="btn-close-support"
                onClick={() => setIsOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-sm cursor-pointer transition-colors"
                aria-label="Close information panel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Content Body */}
            <div className="flex-1 overflow-y-auto space-y-6 pr-1 mr-[-4px] scrollbar-thin scrollbar-thumb-stone-200">
              
              {/* Introduction & Welcome */}
              <div id="info-intro" className="space-y-2">
                <h5 className="font-serif text-sm font-bold text-stone-900 leading-tight">
                  {t.welcome}
                </h5>
                <p className="font-sans text-stone-600 text-xs font-light leading-relaxed">
                  {t.desc}
                </p>
              </div>

              {/* Collapsible/Sleek FAQ block */}
              <div id="info-faqs" className="space-y-3">
                <span className="font-mono text-[9px] uppercase tracking-widest text-[#c5a880] font-bold block mb-1">
                  {t.faqSection}
                </span>

                <div className="space-y-2">
                  {currentFaqList.map((faq, index) => {
                    const isFaqActive = activeFaqIndex === index;
                    return (
                      <div
                        key={index}
                        className="border border-[#e5dfd3]/80 bg-[#fefdfb] rounded-xs overflow-hidden transition-all text-xs"
                      >
                        <button
                          type="button"
                          id={`faq-btn-${index}`}
                          onClick={() => toggleFaq(index)}
                          className="w-full text-left px-3 py-2.5 font-serif font-medium text-stone-900 flex items-center justify-between hover:bg-[#faf8f5] transition-colors cursor-pointer"
                        >
                          <span>{faq.q}</span>
                          <ChevronDown className={`w-3.5 h-3.5 text-[#c5a880] shrink-0 ml-2 transition-transform duration-300 ${isFaqActive ? 'rotate-180' : ''}`} />
                        </button>

                        {isFaqActive && (
                          <div className="px-3 pb-3 pt-1 border-t border-[#e5dfd3]/40 bg-[#faf9f6]/40 font-sans text-stone-650 font-light leading-relaxed animate-fade-in text-[11px]">
                            {Array.isArray(faq.a) ? (
                              <ul className="list-disc list-inside space-y-1 pl-1">
                                {faq.a.map((item, itemIdx) => (
                                  <li key={itemIdx}>{item}</li>
                                ))}
                              </ul>
                            ) : (
                              <p>{faq.a}</p>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Need More Information & Core Contacts */}
              <div id="info-contacts" className="pt-4 border-t border-[#e5dfd3]/70 space-y-4">
                <div className="space-y-1">
                  <span className="font-serif text-xs font-bold text-stone-900 block">
                    {t.needMore}
                  </span>
                  <p className="font-sans text-stone-600 text-[11px] font-light leading-relaxed">
                    {t.moreDesc}
                  </p>
                </div>

                {/* Zemenu Block */}
                <div className="p-3 bg-[#faf9f6] border border-[#e5dfd3]/80 rounded-xs flex flex-col justify-between space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-serif text-xs font-bold text-stone-950 block">{t.contactZemenu}</span>
                      <span className="text-[9px] uppercase font-mono tracking-widest text-stone-400 block mt-0.5">Account Coordinator</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href="https://t.me/+251938322121"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center space-x-1.5 p-2 rounded-xs bg-stone-900 text-stone-50 hover:bg-[#c5a880] hover:text-stone-950 transition-colors font-sans text-[10px] uppercase tracking-wider font-semibold"
                    >
                      <Send className="w-3 h-3" />
                      <span>Telegram</span>
                    </a>
                    <a
                      href="https://www.instagram.com/era__john"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center space-x-1.5 p-2 rounded-xs bg-[#fdfcfa] border border-[#e5dfd3] text-stone-700 hover:border-[#c5a880] hover:text-[#c5a880] transition-colors font-sans text-[10px] uppercase tracking-wider font-semibold"
                    >
                      <Instagram className="w-3" />
                      <span>Instagram</span>
                    </a>
                  </div>
                </div>

                {/* Tijani Block */}
                <div className="p-3 bg-[#faf9f6] border border-[#e5dfd3]/80 rounded-xs flex flex-col justify-between space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-serif text-xs font-bold text-stone-950 block">{t.contactTijani}</span>
                      <span className="text-[9px] uppercase font-mono tracking-widest text-stone-400 block mt-0.5">Technical Lead</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href="https://t.me/tijan_h11"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center space-x-1.5 p-2 rounded-xs bg-stone-900 text-stone-50 hover:bg-[#c5a880] hover:text-stone-950 transition-colors font-sans text-[10px] uppercase tracking-wider font-semibold"
                    >
                      <Send className="w-3 h-3" />
                      <span>Telegram</span>
                    </a>
                    <a
                      href="https://www.instagram.com/tijan.h11"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center space-x-1.5 p-2 rounded-xs bg-[#fdfcfa] border border-[#e5dfd3] text-stone-700 hover:border-[#c5a880] hover:text-[#c5a880] transition-colors font-sans text-[10px] uppercase tracking-wider font-semibold"
                    >
                      <Instagram className="w-3" />
                      <span>Instagram</span>
                    </a>
                  </div>
                </div>

              </div>

            </div>

            {/* Static footer of panel */}
            <div className="pt-3 border-t border-[#e5dfd3] mt-2 shrink-0">
              <p className="font-mono text-[8px] tracking-widest text-stone-400 text-center uppercase">
                Addis Ababa, Ethiopia — 2026
              </p>
            </div>
          </div>
        </>
      )}

      {/* Main Trigger Button */}
      <button
        id="btn-trigger-support"
        onClick={() => setIsOpen(!isOpen)}
        className="group cursor-pointer bg-stone-900 text-amber-50 p-4 rounded-full shadow-2xl hover:bg-[#c5a880] hover:text-[#1c1917] transition-all duration-300 transform hover:scale-105 active:scale-95 flex items-center justify-center focus:ring-2 focus:ring-[#c5a880]/40"
        aria-label="Direct support channel"
      >
        {isOpen ? (
          <X className="w-5 h-5" />
        ) : (
          <div className="flex items-center justify-center relative">
            {/* Ambient Pulse indicator */}
            <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-[#c5a880] animate-ping" />
            <span className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-[#c5a880]" />
            <MessageSquare className="w-5 h-5 transition-transform rotate-0 group-hover:rotate-12" />
          </div>
        )}
      </button>

    </div>
  );
}

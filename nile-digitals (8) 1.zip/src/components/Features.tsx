import { Smartphone, Globe2, Zap, Search, MessageSquareCode, Headphones, Sparkles } from 'lucide-react';
import { Language, translations } from '../types';

interface FeaturesProps {
  currentLang: Language;
}

export default function Features({ currentLang }: FeaturesProps) {
  const t = translations[currentLang];

  const features = [
    {
      id: 'mobile-responsive',
      icon: Smartphone,
      title: t.featResponsive,
      desc: {
        en: 'Perfect display fluid on smartphones, tablets, and full resolution desktop workstations.',
        am: 'በስልኮች፣ ታብሌቶች እና ኮምፒውተሮች ላይ ሙሉ በሙሉ ተስማሚ ሆኖ የሚታይ ንጹህ አቀማመጥ።',
        om: 'Moobaayilaa, taableetota fi qopheessitoota hunda irratti bifa guutuu fi miidhagaan mul\'ata.',
        ti: 'ኣብ ስልኪ፣ ታብሌት ዝሰማማዕን ብሉጽን ዝኾነ ናይ ዓንቀጽ ኣቀማምጣ።'
      }
    },
    {
      id: 'multilingual-support',
      icon: Globe2,
      title: t.featMultilingual,
      desc: {
        en: 'Native English, Amharic, Afaan Oromo, and Tigrinya setup to double your business audience.',
        am: 'የደንበኛ ማህበረሰብዎን በእጥፍ ለማሳደግ በእንግሊዝኛ ፣ አማርኛ ፣ አፋን ኦሮሞ እና ትግርኛ የተዘጋጀ።',
        om: 'Maamiloota daldala keessani dacha dabaluuf Afaan Ingilizii, Amaaraa, Oromoo fi Tigriffatiin qophaa\'e.',
        ti: 'ብቑጽሪ ደንበኛታትኩም ንምዕባይ ብእንግሊዝኛ፣ ኣምሓርኛ፣ ኦሮምኛን ትግርኛን ዝተዳለወ።'
      }
    },
    {
      id: 'fast-loading',
      icon: Zap,
      title: t.featFastLoading,
      desc: {
        en: 'Optimized build assets and lightweight code structures designed to load in milliseconds.',
        am: 'የድረ-ገጽዎን የመጫን ፍጥነት በማሻሻል ደንበኞች ሳይሰለቹ እንዲጠቀሙ ማድረግ።',
        om: 'Moosaajii fi piroojektoota salphaa ta`ani fi daqiiqaa muraasa keessatti banaman.',
        ti: 'ኮድ ጽሬትን ቅልጣፈን ብምዕቃብ ኣብ ውሑድ ሚሊሴኮንድ ዝኽፈት መርበብ ሓበሬታ።'
      }
    },
    {
      id: 'seo-ready',
      icon: Search,
      title: t.featSEO,
      desc: {
        en: 'Rank on top of Google searches for Local Business keywords inside Ethiopia and Africa.',
        am: 'በኢትዮጵያ እና አፍሪካ ውስጥ ለሚፈልጉ ደንበኞችዎ ጎግል ፍለጋ ላይ የመጀመሪያው ረድፍ ላይ መውጣት።',
        om: 'Google irratti daldala keessan salphumatti qunnamtoota gabaa jalqabaa akka argatu gochuu.',
        ti: 'ኣብ ጎግል ትካልኩም ብቀሊሉ ኣብ መጀመሪያ መስርዕ ክረክብ ዘኽእል ኣቃውማ።'
      }
    },
    {
      id: 'whatsapp-integration',
      icon: MessageSquareCode,
      title: t.featWhatsApp,
      desc: {
        en: 'Instant redirect buttons that let users order or chat over WhatsApp with one click.',
        am: 'ደንበኞች በአንድ ጠቅታ ብቻ በቀጥታ ወደ ዋትስአፕዎ በመሄድ ትዕዛዝ እንዲያስተላልፉ ማድረግ።',
        om: 'Qunnamti salphaaf battonni WhatsApp kallattiin daldala keessani qunnamu ni dandeessisa.',
        ti: 'ደንበኛታት ብቀሊሉ ብሓንቲ ጠውቂ ናብ ዋትስኣፕኩም ክኣትዉ ዘኽእል ናይ ርክብ መላግቦ።'
      }
    },
    {
      id: 'customer-support247',
      icon: Headphones,
      title: t.featCustSupport,
      desc: {
        en: 'Dedicated tech help to resolve custom domain issues or update content hassle-free.',
        am: 'ስለ ዶሜይን ወይም ስለ ድረ-ገጽ ይዘት ማሻሻያ የሚረዱ አጋዥ የሆኑ ባለሙያዎች ዝግጁነት።',
        om: 'Dursummaa tajaajila domain fi odeeffannoo weebsaayiti irratti deeggarsa bilisaa.',
        ti: 'ሓገዝ ንናይ ዶሜይን ጸገም ወይ ዝተፈላለዩ ናይ መርበብ ሓበሬታ ማሻሻያታትን።'
      }
    },
    {
      id: 'modern-ui-ux',
      icon: Sparkles,
      title: t.featModernUI,
      desc: {
        en: 'Breathtakingly tailored color schemes and typography designed by elite UI experts.',
        am: 'ልዩ የሆኑ ቀለሞች እና የተመረጡ ውብ ፊደላት ተጣምረው የተሰሩለት የሚስብ ዲዛይን።',
        om: 'Miidhagina dizaayinii beekumsa olaanaa qabuu fi dizaayinaroota elite fi qorattootaan qophaa\'an.',
        ti: 'ብክኢላታት ዩአይ ዝተዳለወ ዝበለጸን ዝማረኸን ናይ ሕብርታትን ፊደላትን ውህደት።'
      }
    }
  ];

  return (
    <section
      id="features"
      className="bg-[#f2eee5] py-20 px-6 md:px-12 border-b border-[#e5dfd3]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Short Header */}
        <div id="features-header" className="max-w-3xl mb-16">
          <span className="font-mono text-xs font-semibold tracking-widest text-[#c5a880] uppercase block mb-3">
            01 / PLATFORM FEATURES
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#1c1917] font-light tracking-tight">
            {t.featuresTitle}
          </h2>
        </div>

        {/* Feature Grid with minimal design cards */}
        <div
          id="features-grid"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12"
        >
          {features.map((feat) => {
            const IconComponent = feat.icon;
            return (
              <div
                key={feat.id}
                id={`feat-card-${feat.id}`}
                className="flex flex-col items-start text-left group transition-all duration-300"
              >
                {/* Minimal Icon with slight gold accent */}
                <div className="p-3 bg-stone-100 rounded-xs border border-stone-200/50 mb-5 group-hover:border-[#c5a880] transition-colors duration-300">
                  <IconComponent className="w-5 h-5 text-[#c5a880]" />
                </div>
                <h3 className="font-serif text-lg text-[#1c1917] font-medium tracking-wide mb-2">
                  {feat.title}
                </h3>
                <p className="font-sans text-stone-600 text-xs leading-relaxed font-light">
                  {feat.desc[currentLang]}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
